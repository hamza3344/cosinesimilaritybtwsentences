﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cosinesimilaritybetweensentences
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var tokensentences1 = textBox1.Text.Split(" ");
            var tokensentences2 = textBox2.Text.Split(" ");
            var occurenceofwords1 = tokensentences1.GroupBy(w => w)
                .ToDictionary(group => group.Key, group => group.Count());
            var occurenceofwords2 = tokensentences2.GroupBy(w => w)
                .ToDictionary(group => group.Key, group => group.Count());
            Dictionary<string, Tuple<int, int>> ocurrencelist = new Dictionary<string, Tuple<int, int>>();
            foreach(var words in occurenceofwords1)
            {
                ocurrencelist.Add(words.Key, Tuple.Create(
                    occurenceofwords1[words.Key], occurenceofwords2.ContainsKey(words.Key) ?
                    occurenceofwords1[words.Key] : 0));
                occurenceofwords2.Remove(words.Key);
            }
            foreach(var words in occurenceofwords2)
            {
                ocurrencelist.Add(words.Key, Tuple.Create(0, occurenceofwords2[words.Key]));
            }
            double dotofsentence = ocurrencelist.Sum(x => x.Value.Item1 * x.Value.Item2);
            double squareroofofsentence1 = Math.Sqrt(ocurrencelist.Sum(
                x=>Math.Pow(x.Value.Item1,2)));
            double squareroofofsentence2 = Math.Sqrt(ocurrencelist.Sum(
                x=>Math.Pow(x.Value.Item2,2)));
            double result = dotofsentence / (squareroofofsentence1 * squareroofofsentence2);
            MessageBox.Show(result + "");
        }
    }
}
